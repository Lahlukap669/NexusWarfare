﻿using Microsoft.Xna.Framework;
using Nexus_Warfare.Source.Graphics;
using Nexus_Warfare.Source.Graphics.MonsterTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nexus_Warfare.Source.Controller
{
    public class WaveManager
    {
        private MonsterManager monsterManager;
        private Random random = new Random();
        private float waveDuration = 60.0f; // 1 minute
        private float spawnInterval = 5.0f; // Spawn a monster every 5 seconds
        private float timeSinceLastSpawn;
        private float waveTimer;

        public WaveManager(MonsterManager monsterManager)
        {
            this.monsterManager = monsterManager;
        }

        public void StartWave()
        {
            waveTimer = 0;
            timeSinceLastSpawn = 0;
            // Additional wave start logic...
        }
        public int GetWaveNumber()
        {
            return (int)(waveTimer / waveDuration) + 1;
        }

        public void Update(GameTime gameTime)
        {
            waveTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
            timeSinceLastSpawn += (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (waveTimer < waveDuration)
            {
                if (timeSinceLastSpawn >= spawnInterval)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        SpawnMonster();
                    }
                    timeSinceLastSpawn = 0;
                }
            }
            else
            {
                // Wave duration ended
                // Prepare for next wave or end wave logic...
            }

            // Other update logic...
        }

        private void SpawnMonster()
        {
            MonsterType type = GetRandomMonsterType();
            int lane = random.Next(1, 6);
            monsterManager.AddMonster(type, lane);
        }
        private MonsterType GetRandomMonsterType()
        {
            Array monsterTypes = Enum.GetValues(typeof(MonsterType));
            MonsterType randomType = (MonsterType)monsterTypes.GetValue(random.Next(monsterTypes.Length));
            return randomType;
        }
    }
}
