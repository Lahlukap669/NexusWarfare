﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Android.Icu.Text.Transliterator;
using Nexus_Warfare.Source.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input.Touch;

namespace Nexus_Warfare.Source.Controller
{

    public class TurretManager
    {
        public List<Turret> turrets { get; set; }
        private List<AnchorPoint> anchorPoints;
        private ContentManager contentManager;
        private Texture2D[] LevelTextures { get; set; }
        private String gun0Texture;
        private Turret selectedTurret;


        public TurretManager(ContentManager content)
        {
            turrets = new List<Turret>();
            anchorPoints = new List<AnchorPoint>();
            InitializeAnchorPoints();
            contentManager = content;
            IntializeGunTextures(contentManager);
            gun0Texture = "Guns/Gun01/Idle/Gun01-Idle_0";
            LoadContent();
        }
        private void InitializeAnchorPoints()
        {
            // Define the anchor points here
            anchorPoints.Add(new AnchorPoint(new Vector2(175, 1400), true));
            anchorPoints.Add(new AnchorPoint(new Vector2(330, 1400), true));
            anchorPoints.Add(new AnchorPoint(new Vector2(475, 1400), true));
            anchorPoints.Add(new AnchorPoint(new Vector2(610, 1400), true));
            anchorPoints.Add(new AnchorPoint(new Vector2(755, 1400), true));
            anchorPoints.Add(new AnchorPoint(new Vector2(900, 1400), true));
            anchorPoints.Add(new AnchorPoint(new Vector2(175, 1620)));
            anchorPoints.Add(new AnchorPoint(new Vector2(330, 1620)));
            anchorPoints.Add(new AnchorPoint(new Vector2(475, 1620)));
            anchorPoints.Add(new AnchorPoint(new Vector2(610, 1620)));
            anchorPoints.Add(new AnchorPoint(new Vector2(755, 1620)));
            anchorPoints.Add(new AnchorPoint(new Vector2(900, 1620)));
            anchorPoints.Add(new AnchorPoint(new Vector2(175, 1750)));
            anchorPoints.Add(new AnchorPoint(new Vector2(330, 1750)));
            anchorPoints.Add(new AnchorPoint(new Vector2(475, 1750)));
            anchorPoints.Add(new AnchorPoint(new Vector2(610, 1750)));
            anchorPoints.Add(new AnchorPoint(new Vector2(755, 1750)));
            anchorPoints.Add(new AnchorPoint(new Vector2(900, 1750)));
        }
        private void IntializeGunTextures(ContentManager contentManager)
        {
            LevelTextures = new Texture2D[3];
            LevelTextures[0] = contentManager.Load<Texture2D>("Guns/Gun01/Idle/Gun01-Idle_0");
            LevelTextures[1] = contentManager.Load<Texture2D>("Guns/Gun02/Idle/Gun02-Idle_0");
            LevelTextures[2] = contentManager.Load<Texture2D>("Guns/Gun03/Idle/Gun03-Idle_0");
        }   

        private void LoadContent()
        {
            PlaceGunAtAvailableAnchor(anchorPoints);
        }
        public List<Turret> GetTurrets()
        {
            return turrets;
        }
        public void PlaceGunAtAvailableAnchor(List<AnchorPoint> anchors)
        {
            foreach (var anchor in anchors)
            {
                if (anchor.IsActive)
                {
                    turrets.Add(new Turret(contentManager, gun0Texture, anchor, LevelTextures)); 
                }
            }
            return;

        }
        public void HandleInput(TouchCollection touchCollection)
        {
            foreach (var touch in touchCollection)
            {
                switch (touch.State)
                {
                    case TouchLocationState.Pressed:
                        foreach (var turret in turrets)
                        {
                            if (turret.GetBoundingRectangle().Contains(touch.Position))
                            {
                                selectedTurret = turret;
                                selectedTurret.isActive = false;
                                break;
                            }
                        }
                        break;

                    case TouchLocationState.Moved:
                        if (selectedTurret != null)
                        {
                            selectedTurret.Position = touch.Position;
                        }
                        break;

                    case TouchLocationState.Released:
                        if (selectedTurret != null)
                        {
                            SnapTurretToAnchor(selectedTurret);
                            selectedTurret = null;
                        }
                        break;
                }
            }
        }

        private void SnapTurretToAnchor(Turret turret)
        {
            AnchorPoint closestAnchor = null;
            float closestDistance = float.MaxValue;

            foreach (var anchor in anchorPoints)
            {
                if (!anchor.IsOccupied)
                {
                    float distance = Vector2.Distance(turret.Position, anchor.Position);

                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestAnchor = anchor;
                    }
                }
            }

            if (closestAnchor != null)
            {
                turret.Position = closestAnchor.Position;
                turret.isActive = closestAnchor.IsActive;
                closestAnchor.IsOccupied = true;
                if (turret.CurrentAnchor != null)
                {
                    turret.CurrentAnchor.IsOccupied = false;
                }
                turret.CurrentAnchor = closestAnchor;
            }
        }


        public void Update(GameTime gameTime)
        {
            foreach (var turret in turrets)
            {
                turret.Update(gameTime);
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (var turret in turrets)
            {
                turret.Draw(spriteBatch);
            }
            if (selectedTurret != null)
            {
                selectedTurret.Draw(spriteBatch);
            }
        }
    }
}
