﻿using Android.Widget;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nexus_Warfare.Source.Scene
{
    public class HUD
    {
        private SpriteFont font;
        private Vector2 position;
        private int score;
        private int health;
        private Vector2 buttonPosition;

        public HUD(SpriteFont font, ContentManager Content)
        {
            this.font = font;
            this.score = 0;
            this.health = 100; // Assuming 100 is the starting health
            this.position = new Vector2(10, 1900);

        }

        public void Update(int score, int health)
        {
            this.score = score;
            this.health = health;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            string hudText = $"Wave: {score}  Health: {health}";
            spriteBatch.DrawString(font, hudText, position, Color.White);
            
        }
    }

}
