﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nexus_Warfare.Source.Graphics
{
    public class Wave
    {
        private bool IsComplete { get; set; }

        public void Start()
        {
            // Initialize the wave
        }

        public void Update(GameTime gameTime)
        {
            // Spawn monsters, update wave status
        }
    }

}
